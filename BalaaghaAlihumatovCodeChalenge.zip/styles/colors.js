export const COLORS  = {
    primary: "#8EC957",
    secondary: "#21295C",
    white:'#ffffff',
    gray:'#AEAEAE',
    lightGray:'#d6d6d6',
    btnColor:'#E0E0E0',

  };
  
  