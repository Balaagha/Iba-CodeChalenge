import img1 from "../assets/images/img.png";



export const IMAGES = Object.freeze({img1});
